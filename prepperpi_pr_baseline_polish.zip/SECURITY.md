# Security Policy

If you discover a security vulnerability in PrepperPi, **please do not open a public issue**.

Instead, email the maintainer at: security@ironwallsecurity.example (replace with your real address).

We will acknowledge receipt within 72 hours and work with you to assess and remediate the issue. When appropriate, we will credit you in the release notes.
